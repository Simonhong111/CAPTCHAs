'''
Created on Jul 13, 2014

@author: Jason Guo E-mail: zqguo@zqguo.com
'''
CAPTCHA_DIR = "./fig/"
BINARY_CAPTCHA_DIR = "./binary/"
CAPTCHA_MODULE = "./captcha/"
LETTER_DIR = "./letter/"
TRAIN_SET_DIR = "./trainset/"
CLASSIFIED_LETTER = "./classified/"

DATA_FILE_NAME = "./identify.pkl"

DOWNLOAD_NUMBER = 30

CAPTCHA_URL = "http://xk.fudan.edu.cn/xk/image.do"