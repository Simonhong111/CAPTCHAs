# -*- coding: UTF-8 -*-
'''
Created on Jul 13, 2014

@author: Jason Guo E-mail: zqguo@zqguo.com
'''
LOGINURL = "http://xk.fudan.edu.cn/xk/loginServlet"
LOGINCAPTCHAURL = "http://xk.fudan.edu.cn/xk/image.do"
DATA_FILE_NAME = "../Model/identify.pkl"
FAIL_IMAGE = "../Model/fail/" 