'''
Created on Jul 13, 2014

@author: Jason Guo E-mail: zqguo@zqguo.com
'''
import View

if __name__ == '__main__':
    main = View.Main()